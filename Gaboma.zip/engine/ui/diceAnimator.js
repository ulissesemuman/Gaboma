/**
 * diceAnimator.js
 *
 * Renders animated SVG dice (D4, D6, D8, D10, D12, D20).
 * Multiple dice of the same roll appear simultaneously.
 * Position is configurable via book.json: ui.dicePosition
 * Supported positions: "center" | "top" | "bottom-left" | "bottom-right"
 */

// ─── SVG face generators ──────────────────────────────────────────────────────

const DICE_FACES = {

  d6: (value) => `
    <svg viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg" class="dice-svg">
      <rect x="2" y="2" width="56" height="56" rx="10" ry="10"
            fill="var(--dice-face)" stroke="var(--dice-border)" stroke-width="2.5"/>
      ${d6Dots(value)}
    </svg>`,

  d4: (value) => `
    <svg viewBox="0 0 60 70" xmlns="http://www.w3.org/2000/svg" class="dice-svg">
      <polygon points="30,4 58,64 2,64"
               fill="var(--dice-face)" stroke="var(--dice-border)" stroke-width="2.5"/>
      <text x="30" y="56" text-anchor="middle"
            font-size="22" font-weight="bold" fill="var(--dice-text)">${value}</text>
    </svg>`,

  d8: (value) => `
    <svg viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg" class="dice-svg">
      <polygon points="30,2 58,30 30,58 2,30"
               fill="var(--dice-face)" stroke="var(--dice-border)" stroke-width="2.5"/>
      <text x="30" y="36" text-anchor="middle"
            font-size="20" font-weight="bold" fill="var(--dice-text)">${value}</text>
    </svg>`,

  d10: (value) => `
    <svg viewBox="0 0 60 70" xmlns="http://www.w3.org/2000/svg" class="dice-svg">
      <polygon points="30,2 58,20 50,58 10,58 2,20"
               fill="var(--dice-face)" stroke="var(--dice-border)" stroke-width="2.5"/>
      <text x="30" y="42" text-anchor="middle"
            font-size="20" font-weight="bold" fill="var(--dice-text)">${value}</text>
    </svg>`,

  d12: (value) => `
    <svg viewBox="0 0 70 70" xmlns="http://www.w3.org/2000/svg" class="dice-svg">
      <polygon points="35,2 62,13 70,42 52,65 18,65 0,42 8,13"
               fill="var(--dice-face)" stroke="var(--dice-border)" stroke-width="2.5"/>
      <text x="35" y="42" text-anchor="middle"
            font-size="19" font-weight="bold" fill="var(--dice-text)">${value}</text>
    </svg>`,

  d20: (value) => `
    <svg viewBox="0 0 60 70" xmlns="http://www.w3.org/2000/svg" class="dice-svg">
      <polygon points="30,2 58,18 58,52 30,68 2,52 2,18"
               fill="var(--dice-face)" stroke="var(--dice-border)" stroke-width="2.5"/>
      <text x="30" y="42" text-anchor="middle"
            font-size="20" font-weight="bold" fill="var(--dice-text)">${value}</text>
    </svg>`,
};

// D6 dot layout — classic pip positions
function d6Dots(value) {
  const positions = {
    1: [[30, 30]],
    2: [[18, 18], [42, 42]],
    3: [[18, 18], [30, 30], [42, 42]],
    4: [[18, 18], [42, 18], [18, 42], [42, 42]],
    5: [[18, 18], [42, 18], [30, 30], [18, 42], [42, 42]],
    6: [[18, 16], [42, 16], [18, 30], [42, 30], [18, 44], [42, 44]],
  };

  return (positions[value] || []).map(([cx, cy]) =>
    `<circle cx="${cx}" cy="${cy}" r="5" fill="var(--dice-text)"/>`
  ).join("");
}

// ─── Position map ─────────────────────────────────────────────────────────────

const POSITION_STYLES = {
  center:       "top:50%;left:50%;transform:translate(-50%,-50%)",
  top:          "top:80px;left:50%;transform:translateX(-50%)",
  "bottom-left":  "bottom:80px;left:24px",
  "bottom-right": "bottom:80px;right:24px",
};

// ─── CSS injection (once) ─────────────────────────────────────────────────────

let cssInjected = false;

function injectCSS() {
  if (cssInjected) return;
  cssInjected = true;

  const style = document.createElement("style");
  style.textContent = `
    :root {
      --dice-face:   var(--color-surface, #f5f0e8);
      --dice-border: var(--color-primary, #5a3e28);
      --dice-text:   var(--color-primary, #5a3e28);
    }

    .dice-overlay {
      position: fixed;
      z-index: 1000;
      display: flex;
      gap: 12px;
      align-items: center;
      justify-content: center;
      pointer-events: none;
    }

    .dice-wrapper {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 4px;
    }

    .dice-svg {
      width: 64px;
      height: 64px;
      filter: drop-shadow(0 4px 12px rgba(0,0,0,0.35));
    }

    .dice-value-label {
      font-size: 13px;
      font-weight: bold;
      color: var(--dice-text);
      opacity: 0;
      transition: opacity 0.3s ease;
    }

    /* rolling: shake + spin */
    @keyframes dice-roll {
      0%   { transform: rotate(0deg)   scale(1);    }
      15%  { transform: rotate(-18deg) scale(1.12); }
      30%  { transform: rotate(14deg)  scale(0.95); }
      50%  { transform: rotate(-10deg) scale(1.08); }
      70%  { transform: rotate(8deg)   scale(0.97); }
      85%  { transform: rotate(-5deg)  scale(1.03); }
      100% { transform: rotate(0deg)   scale(1);    }
    }

    .dice-rolling .dice-svg {
      animation: dice-roll 0.18s ease-in-out infinite;
    }

    /* settle: bounce in */
    @keyframes dice-settle {
      0%   { transform: scale(1.3) rotate(8deg);  opacity: 0.6; }
      60%  { transform: scale(0.92) rotate(-3deg); opacity: 1;   }
      80%  { transform: scale(1.05) rotate(1deg);  }
      100% { transform: scale(1) rotate(0deg);     opacity: 1;   }
    }

    .dice-settling .dice-svg {
      animation: dice-settle 0.4s cubic-bezier(0.34,1.56,0.64,1) forwards;
    }

    /* fade out entire overlay */
    @keyframes dice-fadeout {
      0%   { opacity: 1; transform: scale(1);    }
      100% { opacity: 0; transform: scale(0.85); }
    }

    .dice-overlay.hiding {
      animation: dice-fadeout 0.35s ease-in forwards;
    }

    /* total result badge */
    .dice-total-badge {
      margin-top: 6px;
      padding: 4px 14px;
      background: var(--color-primary, #5a3e28);
      color: var(--color-surface, #f5f0e8);
      border-radius: 20px;
      font-size: 15px;
      font-weight: bold;
      opacity: 0;
      transform: translateY(8px);
      transition: opacity 0.3s ease, transform 0.3s ease;
    }
  `;

  document.head.appendChild(style);
}

// ─── Public API ───────────────────────────────────────────────────────────────

/**
 * Plays a dice roll animation and resolves when complete.
 *
 * @param {Object} diceEvent  - { dice: { count, sides }, results: [], total }
 * @param {string} position   - override position; falls back to book config or "center"
 * @returns {Promise<void>}   - resolves after animation + display time
 */
export function playDiceAnimation(diceEvent, position = null) {
  return new Promise(resolve => {
    injectCSS();

    const { dice, results, total } = diceEvent;
    const sides  = dice.sides;
    const faceKey = `d${sides}`;
    const pos    = position ?? _resolvePosition();
    const posStyle = POSITION_STYLES[pos] ?? POSITION_STYLES.center;

    // ── Build overlay ─────────────────────────────────────────────
    const overlay = document.createElement("div");
    overlay.className = "dice-overlay";
    overlay.style.cssText = posStyle;

    const wrappers = results.map((result, i) => {
      const wrapper = document.createElement("div");
      wrapper.className = "dice-wrapper dice-rolling";

      // Show a random rolling face during animation
      wrapper.innerHTML = _randomFace(faceKey, sides);

      const label = document.createElement("div");
      label.className = "dice-value-label";
      label.textContent = result;
      wrapper.appendChild(label);

      overlay.appendChild(wrapper);
      return { wrapper, result, label };
    });

    // Total badge (only when more than 1 die)
    let totalBadge = null;
    if (results.length > 1) {
      totalBadge = document.createElement("div");
      totalBadge.className = "dice-total-badge";
      totalBadge.textContent = `= ${total}`;
      overlay.appendChild(totalBadge);
    }

    document.body.appendChild(overlay);

    // ── Rolling phase (700ms) ─────────────────────────────────────
    const rollInterval = setInterval(() => {
      wrappers.forEach(({ wrapper }) => {
        const face = _randomFace(faceKey, sides);
        // replace SVG only (not the label)
        const existing = wrapper.querySelector(".dice-svg");
        if (existing) wrapper.replaceChild(
          _svgElement(face), existing
        );
      });
    }, 80);

    // ── Settle phase ──────────────────────────────────────────────
    setTimeout(() => {
      clearInterval(rollInterval);

      wrappers.forEach(({ wrapper, result, label }) => {
        wrapper.classList.remove("dice-rolling");
        wrapper.classList.add("dice-settling");

        // Show final value
        const finalFace = DICE_FACES[faceKey]
          ? DICE_FACES[faceKey](result)
          : DICE_FACES.d6(result);

        const existing = wrapper.querySelector(".dice-svg");
        if (existing) wrapper.replaceChild(
          _svgElement(finalFace), existing
        );

        // Reveal label
        setTimeout(() => { label.style.opacity = "1"; }, 300);
      });

      // Reveal total badge
      if (totalBadge) {
        setTimeout(() => {
          totalBadge.style.opacity = "1";
          totalBadge.style.transform = "translateY(0)";
        }, 400);
      }
    }, 700);

    // ── Display phase (2s) + fade out ─────────────────────────────
    setTimeout(() => {
      overlay.classList.add("hiding");
      setTimeout(() => {
        overlay.remove();
        resolve();
      }, 350);
    }, 700 + 2000);
  });
}

// ─── Internal helpers ─────────────────────────────────────────────────────────

function _randomFace(faceKey, sides) {
  const randomVal = Math.floor(Math.random() * sides) + 1;
  const generator = DICE_FACES[faceKey] ?? DICE_FACES.d6;
  return generator(randomVal);
}

function _svgElement(html) {
  const div = document.createElement("div");
  div.innerHTML = html.trim();
  return div.firstChild;
}

function _resolvePosition() {
  // Try to read from current book manifest
  try {
    const { BookLoader } = window._gaboma ?? {};
    const book = BookLoader?.getCurrentBook?.();
    return book?.manifest?.ui?.dicePosition ?? "center";
  } catch {
    return "center";
  }
}

export const DiceAnimator = { playDiceAnimation };
