/**
 * messageAnimator.js
 *
 * Two animation styles for feedback messages:
 *   - "explosion" : pops from center, scales up elastically, fades out expanding
 *   - "slide"     : rises from below the screen, bounces at destination, descends slowly
 *
 * Default style set globally. Override per book via book.json → ui.messageStyle
 */

let _engineDefault = "slide";

export function setDefaultMessageStyle(style) {
  if (style === "explosion" || style === "slide") {
    _engineDefault = style;
  }
}

// ─── CSS ─────────────────────────────────────────────────────────────────────

let cssInjected = false;

function injectCSS() {
  if (cssInjected) return;
  cssInjected = true;

  const style = document.createElement("style");
  style.textContent = `
    .feedback-message {
      position: fixed;
      z-index: 900;
      left: 50%;
      transform: translateX(-50%);
      max-width: 80vw;
      white-space: normal;
      text-align: center;
      padding: 10px 20px;
      border-radius: 24px;
      font-size: 15px;
      font-weight: 600;
      line-height: 1.4;
      pointer-events: none;
      background: var(--color-primary, #5a3e28);
      color: var(--color-surface, #f5f0e8);
      box-shadow: 0 4px 20px rgba(0,0,0,0.28);
    }

    /* ── Explosion ──────────────────────────────────────────────────── */
    @keyframes msg-explode-in {
      0%   { opacity: 0; transform: translateX(-50%) scale(0.3);  }
      60%  { opacity: 1; transform: translateX(-50%) scale(1.08); }
      100% { opacity: 1; transform: translateX(-50%) scale(1);    }
    }
    @keyframes msg-explode-out {
      0%   { opacity: 1; transform: translateX(-50%) scale(1);   }
      100% { opacity: 0; transform: translateX(-50%) scale(1.4); }
    }
    .feedback-message.style-explosion {
      top: 42%;
    }
    .feedback-message.style-explosion.phase-in {
      animation: msg-explode-in 0.3s cubic-bezier(0.34,1.56,0.64,1) forwards;
    }
    .feedback-message.style-explosion.phase-out {
      animation: msg-explode-out 0.35s ease-in forwards;
    }

    /* ── Slide ──────────────────────────────────────────────────────── */
    /*
     * The element sits at bottom: REST_BOTTOM (final resting position).
     * Phase-in animates from below the viewport up to REST_BOTTOM with a
     * small bounce overshoot. Phase-out slides back below the viewport.
     * We use a CSS custom property so JS can set the exact resting position.
     */
    .feedback-message.style-slide {
      bottom: var(--msg-rest, 88px);
      /* start hidden below screen — JS sets opacity:0 before appending */
      opacity: 0;
    }

    @keyframes msg-slide-in {
      0%   { opacity: 0;   bottom: -80px;                              }
      55%  { opacity: 1;   bottom: calc(var(--msg-rest, 88px) + 14px); }
      72%  { opacity: 1;   bottom: calc(var(--msg-rest, 88px) - 6px);  }
      85%  { opacity: 1;   bottom: calc(var(--msg-rest, 88px) + 4px);  }
      100% { opacity: 1;   bottom: var(--msg-rest, 88px);              }
    }

    @keyframes msg-slide-out {
      0%   { opacity: 1; bottom: var(--msg-rest, 88px); }
      100% { opacity: 0; bottom: -80px;                 }
    }

    .feedback-message.style-slide.phase-in {
      animation: msg-slide-in 0.52s cubic-bezier(0.22,1,0.36,1) forwards;
    }

    .feedback-message.style-slide.phase-out {
      animation: msg-slide-out 0.48s cubic-bezier(0.55,0,1,0.45) forwards;
    }
  `;

  document.head.appendChild(style);
}

// ─── Public API ───────────────────────────────────────────────────────────────

/**
 * @param {string}  text
 * @param {number}  [duration=2200]   - hold time in ms between in and out animations
 * @param {string}  [styleOverride]   - "explosion" | "slide" | null
 * @returns {Promise<void>}
 */
export function showMessage(text, duration = 2200, styleOverride = null) {
  return new Promise(resolve => {
    injectCSS();

    const style    = styleOverride ?? _resolveBookStyle() ?? _engineDefault;
    const isSlide  = style === "slide";

    const el = document.createElement("div");
    el.className = `feedback-message style-${style}`;
    el.textContent = text;

    // For slide: set resting position above the bottom bar (88px default).
    // The bottom bar is ~56px tall; add a small gap.
    if (isSlide) {
      const bottomBar = document.getElementById("bottom-bar");
      const barHeight = bottomBar ? bottomBar.offsetHeight : 56;
      el.style.setProperty("--msg-rest", `${barHeight + 16}px`);
    }

    document.body.appendChild(el);

    // Trigger in-animation on next frame so the element is in the DOM first
    requestAnimationFrame(() => {
      el.classList.add("phase-in");
    });

    const inDuration  = isSlide ? 520 : 300;
    const outDuration = isSlide ? 480 : 350;

    setTimeout(() => {
      el.classList.remove("phase-in");
      el.classList.add("phase-out");

      setTimeout(() => {
        el.remove();
        resolve();
      }, outDuration);

    }, inDuration + duration);
  });
}

function _resolveBookStyle() {
  try {
    const book = window._gaboma?.BookLoader?.getCurrentBook?.();
    return book?.manifest?.ui?.messageStyle ?? null;
  } catch {
    return null;
  }
}

export const MessageAnimator = { showMessage, setDefaultMessageStyle };